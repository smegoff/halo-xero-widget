import express from "express";
import axios from "axios";
import NodeCache from "node-cache";
import dotenv from "dotenv";
dotenv.config();

const app = express();
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const cache = new NodeCache({ stdTTL: 120 }); // 2-minute cache

let tokens = { access_token: "", refresh_token: "" };
let tenantId = process.env.TENANT_ID;

// ---------- OAuth handshake ----------
app.get("/auth/connect", (req, res) => {
  const url = `https://login.xero.com/identity/connect/authorize?response_type=code&client_id=${process.env.XERO_CLIENT_ID}&redirect_uri=${process.env.XERO_REDIRECT_URI}&scope=accounting.transactions accounting.contacts offline_access`;
  res.redirect(url);
});

app.get("/auth/callback", async (req, res) => {
  const code = req.query.code;
  const r = await axios.post("https://identity.xero.com/connect/token",
    new URLSearchParams({
      grant_type: "authorization_code",
      code,
      redirect_uri: process.env.XERO_REDIRECT_URI,
      client_id: process.env.XERO_CLIENT_ID,
      client_secret: process.env.XERO_CLIENT_SECRET,
    }),
    { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
  );
  tokens = r.data;

  // get tenant id
  const tenants = await axios.get("https://api.xero.com/connections", {
    headers: { Authorization: `Bearer ${tokens.access_token}` },
  });
  tenantId = tenants.data[0].tenantId;
  console.log("Connected to tenant:", tenantId);
  res.send("✅ Authorised – you can close this tab.");
});

// ---------- Helper ----------
async function ensureToken() {
  if (!tokens.refresh_token) throw new Error("Not authorised yet.");
  // refresh if needed
  const r = await axios.post("https://identity.xero.com/connect/token",
    new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: tokens.refresh_token,
      client_id: process.env.XERO_CLIENT_ID,
      client_secret: process.env.XERO_CLIENT_SECRET,
    }),
    { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
  );
  tokens = r.data;
  return tokens.access_token;
}

// ---------- Finance view ----------
app.get("/finance", async (req, res) => {
  try {
    const contactId = req.query.contactId;
    if (!contactId) return res.status(400).send("Missing contactId");

    const cached = cache.get(contactId);
    if (cached) return res.render("finance", cached);

    const token = await ensureToken();
    const headers = {
      Authorization: `Bearer ${token}`,
      "Xero-tenant-id": tenantId,
      Accept: "application/json",
    };

    // invoices
    const inv = await axios.get(
      `https://api.xero.com/api.xro/2.0/Invoices?where=Contact.ContactID==Guid("${contactId}")&order=Date DESC`,
      { headers }
    );
    // credit notes
    const crd = await axios.get(
      `https://api.xero.com/api.xro/2.0/CreditNotes?where=Contact.ContactID==Guid("${contactId}")&order=Date DESC`,
      { headers }
    );

    const rows = [];
    let accountBal = 0, overdueBal = 0;
    const today = new Date();

    function pushDocs(list, type) {
      for (const d of list) {
        const balance = d.AmountDue ?? d.RemainingCredit ?? 0;
        const total = d.Total ?? 0;
        if (type === "CreditNote") accountBal -= balance; else accountBal += balance;
        if (new Date(d.DueDate) < today && balance > 0) overdueBal += balance;
        rows.push({
          name: d.Contact?.Name,
          date: d.DateString?.slice(0,10),
          type,
          number: d.InvoiceNumber || d.CreditNoteNumber,
          due: d.DueDateString?.slice(0,10),
          total: total.toFixed(2),
          balance: balance.toFixed(2),
        });
      }
    }

    pushDocs(inv.data.Invoices || [], "Invoice");
    pushDocs(crd.data.CreditNotes || [], "CreditNote");

    const data = {
      accountBal: accountBal.toFixed(2),
      overdueBal: overdueBal.toFixed(2),
      rows,
      asAt: new Date().toLocaleString("en-NZ"),
    };
    cache.set(contactId, data);
    res.render("finance", data);
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Error fetching data – see logs.");
  }
});

// ---------- EJS template ----------
app.get("/", (_, res) => res.send("Halo↔Xero widget up"));

app.listen(process.env.PORT, () =>
  console.log(`Running on http://localhost:${process.env.PORT}`)
);